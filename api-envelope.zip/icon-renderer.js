/** Shared Lucide SVG renderer for Apps Script HTML and browser updates. */
function renderLucideIcon_(name, label, className) {
  const nodes = getLucideIconNodes_();
  if (!Object.prototype.hasOwnProperty.call(nodes, name)) throw new Error('Unknown Lucide icon: ' + name);
  const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const extraClass = className ? ' ' + escape(className) : '';
  const accessible = label ? 'tabindex="0" role="img" aria-label="' + escape(label) + '"' : 'aria-hidden="true"';
  return '<svg xmlns="http://www.w3.org/2000/svg" class="lucide-icon lucide-' + name + (label ? ' pointer-events-auto' : ' pointer-events-none') + extraClass + '" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" focusable="' + (label ? 'true' : 'false') + '" ' + accessible + '>' + (label ? '<title>' + escape(label) + '</title>' : '') + nodes[name] + '</svg>';
}

/** Body-mounted positioning is retained for icons inside clipped tables, drawers and scroll regions. */
/** Delegated tooltip events also cover content replaced by asynchronous refreshes. */
function initializeDashboardTooltips_() {
  let tooltip = null, active = null, oldDescription = null, nativeTitle = null;
  function hide() {
    if (tooltip) tooltip.hidden = true;
    if (active) {
      if (oldDescription === null) active.removeAttribute('aria-describedby');
      else active.setAttribute('aria-describedby', oldDescription);
      if (nativeTitle !== null) active.setAttribute('title', nativeTitle);
    }
    active = null;
  }
  function show(target) {
    if (!target || !target.closest) return;
    const nativeOwner = target.closest('[data-native-tooltip]');
    if (nativeOwner && nativeOwner.getAttribute('data-native-tooltip') !== null) { hide(); return; }
    const owner = target.closest('[data-tooltip], [title], svg[aria-label]');
    if (!owner || owner === active) return;
    // Fixed positioning is required only when an ancestor clips CSS tooltips.
    if (!owner.closest('[data-tooltip-boundary]')) { hide(); return; }
    const text = owner.getAttribute('data-tooltip') || owner.getAttribute('title') || owner.getAttribute('aria-label');
    if (!text) return;
    hide();
    if (!tooltip) {
      tooltip = document.createElement('div');
      tooltip.id = 'dashboardTooltip'; tooltip.className = 'dashboard-tooltip pointer-events-none fixed z-[60] max-w-[min(280px,calc(100vw-16px))]';
      tooltip.setAttribute('role', 'tooltip');
    }
    // Modal dialogs occupy the top layer, above any body-level z-index.
    // Reattach on every show: refreshing a drawer can remove its old children.
    const host = owner.closest('dialog[open]') || document.body;
    if (tooltip.parentNode !== host) host.appendChild(tooltip);
    active = owner;
    oldDescription = owner.getAttribute('aria-describedby');
    nativeTitle = owner.getAttribute('title');
    if (nativeTitle !== null) owner.removeAttribute('title');
    owner.setAttribute('aria-describedby', (oldDescription ? oldDescription + ' ' : '') + tooltip.id);
    tooltip.textContent = text; tooltip.hidden = false;
    tooltip.style.left = '0px'; tooltip.style.top = '0px';
    const rect = owner.getBoundingClientRect();
    const box = tooltip.getBoundingClientRect();
    const left = Math.max(8, Math.min(rect.left + (rect.width - box.width) / 2, window.innerWidth - box.width - 8));
    const top = rect.top >= box.height + 16 ? rect.top - box.height - 8 : Math.min(rect.bottom + 8, window.innerHeight - box.height - 8);
    tooltip.style.left = left + 'px'; tooltip.style.top = Math.max(8, top) + 'px';
  }
  document.addEventListener('pointerover', event => show(event.target));
  document.addEventListener('focusin', event => show(event.target));
  function leave(event) {
    if (active && (!event.relatedTarget || !active.contains(event.relatedTarget))) hide();
  }
  document.addEventListener('pointerout', leave);
  document.addEventListener('focusout', leave);
  document.addEventListener('keydown', event => { if (event.key === 'Escape') hide(); });
  document.addEventListener('scroll', hide, true);
  document.addEventListener('click', hide);
  document.addEventListener('close', hide, true);
  if (window.addEventListener) window.addEventListener('resize', hide);
}
